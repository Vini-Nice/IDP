// import Image from "next/image";
// import PropTypes, { string } from "prop-types";

// export default function CardNoticies() {
//   const CardNoticies = {
//     imageSrc: string,
//     imageAlt: string,
//     title: string,
//     content: string,
//   };
//   return (
//     <div className="text-slate-700">
//       <div>
//         <h2>{title} </h2>
//       </div>
//       <div>
//         <Image
//           src={imageSrc}
//           alt={imageAlt}
//           className="object-cover shadow-black shadow-md"
//           quality={100}
//           layout="responsive"
//           width={200}
//           height={300}
//         />
//       </div>
//       <div> 
//         <p>{content}</p>
//         Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quod quis
//         minus soluta tempore ab eligendi molestiae, excepturi, eius alias ipsa
//         voluptatibus natus voluptate quibusdam possimus reprehenderit.
//         Assumenda, totam. Sit, laboriosam?
//       </div>
//     </div>
//   );
// }
